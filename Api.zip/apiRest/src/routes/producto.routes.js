import { Router } from "express";
import { methods as productoController} from "../controllers/producto.controller";

const router = Router();

router.get("/", productoController.getProductos);
router.get("/:codigoProducto", productoController.getProducto);
router.post("/", productoController.addProducto);
router.put("/:codigoProducto", productoController.updateProducto);
router.delete("/:codigoProducto", productoController.deleteProducto);


export default router;