import express, { json } from "express";
import morgan from "morgan";
//Routers
import productoRoutes from "./routes/producto.routes";

const app = express();

//settings
app.set("port", 8000);

//middlewares
app.use(morgan("dev"));
app.use(express.json());
app.use(express,json())

//routes
app.use("/api/productos",productoRoutes);

export default app;