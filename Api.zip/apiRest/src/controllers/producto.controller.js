
import { getConnection } from "./../database/database";

const getProductos = async (req, res) => {
    try {
        const connection = await getConnection();
        const result = await connection.query("SELECT codigoProducto, marca, codigo, nombre, precio, fecha FROM producto");
        res.json(result);
    } catch (error) {
        res.status(500);
        res.send(error.message);
    }
};

const getProducto = async (req, res) => {
    try {
        const { codigoProducto } = req.params;
        const connection = await getConnection();
        const result = await connection.query("SELECT codigoProducto, marca, codigo, nombre, precio, fecha FROM producto WHERE id = ?", codigoProducto);
        res.json(result);
    } catch (error) {
        res.status(500);
        res.send(error.message);
    }
};

const addProducto = async (req, res) => {
    try {
        const { codigoProducto, marca, codigo, nombre, precio, fecha } = req.body;

        if (name === undefined || programmers === undefined) {
            res.status(400).json({ message: "Bad Request. Please fill all field." });
        }

        const producto = {codigoProducto, marca, codigo, nombre, precio, fecha};
        const connection = await getConnection();
        await connection.query("INSERT INTO producto SET ?", producto);
        res.json({ message: "Producto agregado" });
    } catch (error) {
        res.status(500);
        res.send(error.message);
    }
};

const updateProducto = async (req, res) => {
    try {
        const { codigoProducto } = req.params;
        const { marca, codigo, nombre, precio, fecha } = req.body;

        if (id === undefined || name === undefined || programmers === undefined) {
            res.status(400).json({ message: "Bad Request. Please fill all field." });
        }

        const language = {codigoProducto, marca, codigo, nombre, precio, fecha};
        const connection = await getConnection();
        const result = await connection.query("UPDATE producto SET ? WHERE id = ?", [producto, codigoProducto]);
        res.json(result);
    } catch (error) {
        res.status(500);
        res.send(error.message);
    }
};

const deleteProducto = async (req, res) => {
    try {
        const { codigoProducto } = req.params;
        const connection = await getConnection();
        const result = await connection.query("DELETE FROM producto WHERE id = ?", codigoProducto);
        res.json(result);
    } catch (error) {
        res.status(500);
        res.send(error.message);
    }
};

export const methods = {
    getProductos,
    getProducto,
    addProducto,
    updateProducto,
    deleteProducto
};
